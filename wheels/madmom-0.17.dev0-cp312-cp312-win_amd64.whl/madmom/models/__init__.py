"""Placeholder for madmom's pretrained models.

RS Studio's Windows wheel leaves the model files out (they are CC BY-NC-SA,
madmom/models upstream). madmom imports this package unconditionally, so it
has to exist; RS Studio only uses the DBN trackers, which need no models.
"""
